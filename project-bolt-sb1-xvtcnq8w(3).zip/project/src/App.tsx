import React, { useState, useCallback } from 'react';
import { ImageUploader } from './components/ImageUploader';
import { BeadPattern } from './components/BeadPattern';
import { ColorLegend } from './components/ColorLegend';
import { PatternControls } from './components/PatternControls';
import { BeadTypeSelector } from './components/BeadTypeSelector';
import { findClosestColor } from './utils/colors';
import { PixelData, BeadColor, PatternOptions, BeadType } from './types';
import { Grid } from 'lucide-react';

export default function App() {
  const [pixels, setPixels] = useState<PixelData[]>([]);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const [colorCounts, setColorCounts] = useState<{ color: BeadColor; count: number }[]>([]);
  const [options, setOptions] = useState<PatternOptions>({
    width: 140,
    showGrid: true,
    patternStyle: 'colors',
    beadType: 'MINI'
  });

  const processImage = useCallback(async (file: File) => {
    const img = new Image();
    img.src = URL.createObjectURL(file);
    
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const scale = options.width / img.width;
      const width = options.width;
      const height = Math.round(img.height * scale);
      
      canvas.width = width;
      canvas.height = height;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      ctx.drawImage(img, 0, 0, width, height);
      const imageData = ctx.getImageData(0, 0, width, height);
      
      const newPixels: PixelData[] = [];
      const colorMap = new Map<string, number>();
      
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const i = (y * width + x) * 4;
          const r = imageData.data[i];
          const g = imageData.data[i + 1];
          const b = imageData.data[i + 2];
          
          const color = findClosestColor(r, g, b, options.beadType);
          newPixels.push({ x, y, color });
          
          colorMap.set(color.code, (colorMap.get(color.code) || 0) + 1);
        }
      }
      
      setPixels(newPixels);
      setDimensions({ width, height });
      
      const counts = Array.from(colorMap.entries()).map(([code, count]) => ({
        color: newPixels.find(p => p.color.code === code)!.color,
        count
      }));
      setColorCounts(counts);
    };
  }, [options.width, options.beadType]);

  const handleBeadTypeChange = (beadType: BeadType) => {
    setOptions(prev => ({ ...prev, beadType }));
    setPixels([]);
    setColorCounts([]);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-2">
            <Grid className="w-8 h-8" />
            Créateur de Motifs en Perles - Convertissez vos images en designs pixelisés
          </h1>
          <p className="mt-2 text-gray-600">
            Convertissez vos images en superbes motifs de perles
          </p>
        </div>

        <BeadTypeSelector
          selectedType={options.beadType}
          onTypeChange={handleBeadTypeChange}
        />

        <PatternControls options={options} onOptionsChange={setOptions} />

        {pixels.length === 0 ? (
          <div className="mt-6">
            <ImageUploader onImageSelect={processImage} />
          </div>
        ) : (
          <div className="space-y-6 mt-6">
            <div className="flex justify-center">
              <BeadPattern
                pixels={pixels}
                width={dimensions.width}
                height={dimensions.height}
                showGrid={options.showGrid}
                patternStyle={options.patternStyle}
              />
            </div>
            <ColorLegend colors={colorCounts} />
            <div className="flex justify-center">
              <button
                onClick={() => {
                  setPixels([]);
                  setColorCounts([]);
                }}
                className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
              >
                Importez votre image
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}