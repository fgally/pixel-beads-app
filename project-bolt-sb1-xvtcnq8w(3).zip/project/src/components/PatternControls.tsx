import React from 'react';
import { PatternOptions } from '../types';

interface PatternControlsProps {
  options: PatternOptions;
  onOptionsChange: (options: PatternOptions) => void;
}

export function PatternControls({ options, onOptionsChange }: PatternControlsProps) {
  const handleNumberInput = (value: string, field: 'width') => {
    const num = parseInt(value, 10);
    if (!isNaN(num)) {
      onOptionsChange({
        ...options,
        [field]: num
      });
    }
  };

  return (
    <div className="space-y-4 bg-white p-6 rounded-lg shadow-sm">
      <div>
        <label className="block text-sm font-medium text-gray-700">
          Width (Number of Beads)
        </label>
        <input
          type="number"
          min="10"
          max="200"
          value={options.width}
          onChange={(e) => handleNumberInput(e.target.value, 'width')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      </div>

      <div className="flex items-center space-x-4">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={options.showGrid}
            onChange={(e) => onOptionsChange({
              ...options,
              showGrid: e.target.checked
            })}
            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-700">Show Grid</span>
        </label>

        <div className="flex items-center space-x-2">
          <label className="text-sm text-gray-700">Pattern Style:</label>
          <select
            value={options.patternStyle}
            onChange={(e) => onOptionsChange({
              ...options,
              patternStyle: e.target.value as PatternOptions['patternStyle']
            })}
            className="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="colors">Colors</option>
            <option value="symbols">Symbols</option>
          </select>
        </div>
      </div>
    </div>
  );
}