import React from 'react';
import { PixelData } from '../types';

interface BeadPatternProps {
  pixels: PixelData[];
  width: number;
  height: number;
  showGrid: boolean;
  patternStyle: 'symbols' | 'colors';
}

const SYMBOLS = ['●', '■', '▲', '◆', '★', '♦', '♥', '♠', '♣', '⬟', '⬢', '⬡'];

export function BeadPattern({ pixels, width, height, showGrid, patternStyle }: BeadPatternProps) {
  const pixelSize = Math.min(600 / width, 600 / height);
  const usedColors = new Set(pixels.map(p => p.color.code));
  const colorToSymbol = new Map([...usedColors].map((code, i) => [code, SYMBOLS[i % SYMBOLS.length]]));

  return (
    <div className="relative border border-gray-200 rounded-lg overflow-hidden">
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${width}, ${pixelSize}px)`,
          width: width * pixelSize,
          height: height * pixelSize,
        }}
      >
        {pixels.map((pixel, index) => (
          <div
            key={index}
            style={{
              backgroundColor: patternStyle === 'colors' ? pixel.color.hex : '#ffffff',
              width: pixelSize,
              height: pixelSize,
              border: showGrid ? '0.5px solid rgba(0,0,0,0.1)' : 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: `${pixelSize * 0.6}px`,
              color: patternStyle === 'symbols' ? pixel.color.hex : 'transparent',
            }}
            title={`${pixel.color.name} (${pixel.color.code})`}
          >
            {patternStyle === 'symbols' && colorToSymbol.get(pixel.color.code)}
          </div>
        ))}
      </div>
    </div>
  );
}