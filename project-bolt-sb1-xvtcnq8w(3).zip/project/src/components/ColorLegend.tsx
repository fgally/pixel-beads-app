import React from 'react';
import { BeadColor } from '../types';

interface ColorLegendProps {
  colors: { color: BeadColor; count: number }[];
}

export function ColorLegend({ colors }: ColorLegendProps) {
  return (
    <div className="mt-6">
      <h3 className="text-lg font-semibold mb-2">Color Overview</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {colors.map(({ color, count }) => (
          <div
            key={color.code}
            className="flex items-center space-x-2 p-2 rounded-md border border-gray-200"
          >
            <div
              className="w-6 h-6 rounded-full"
              style={{ backgroundColor: color.hex }}
            />
            <div>
              <p className="text-sm font-medium">{color.name}</p>
              <p className="text-xs text-gray-500">Count: {count}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}