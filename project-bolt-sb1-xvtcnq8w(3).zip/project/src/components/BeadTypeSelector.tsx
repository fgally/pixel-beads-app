import React from 'react';
import { BeadType } from '../types';

interface BeadTypeSelectorProps {
  selectedType: BeadType;
  onTypeChange: (type: BeadType) => void;
}

export function BeadTypeSelector({ selectedType, onTypeChange }: BeadTypeSelectorProps) {
  return (
    <div className="flex items-center space-x-4 mb-4">
      <span className="text-sm font-medium text-gray-700">Bead Type:</span>
      <div className="flex space-x-2">
        <button
          onClick={() => onTypeChange('MINI')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            selectedType === 'MINI'
              ? 'bg-blue-500 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          MINI
        </button>
        <button
          onClick={() => onTypeChange('MAXI')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            selectedType === 'MAXI'
              ? 'bg-blue-500 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          MAXI
        </button>
      </div>
    </div>
  );
}