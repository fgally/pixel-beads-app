export const MAXI_BEAD_COLORS = [
  { id: '01', code: 'white', name: 'White', hex: '#FFFFFF' },
  { id: '03', code: 'yellow', name: 'Yellow', hex: '#FFD700' },
  { id: '05', code: 'red', name: 'Red', hex: '#FF0000' },
  { id: '07', code: 'purple', name: 'Purple', hex: '#800080' },
  { id: '09', code: 'blue', name: 'Blue', hex: '#0000FF' },
  { id: '10', code: 'green', name: 'Green', hex: '#008000' },
  { id: '17', code: 'grey', name: 'Grey', hex: '#808080' },
  { id: '18', code: 'black', name: 'Black', hex: '#000000' },
  { id: '20', code: 'caramel', name: 'Caramel', hex: '#C19A6B' },
  { id: '26', code: 'matte-pink', name: 'Matte Pink', hex: '#F4C2C2' },
  { id: '32', code: 'neon-fuchsia', name: 'Neon Fuchsia', hex: '#FF007F' },
  { id: '34', code: 'neon-yellow', name: 'Neon Yellow', hex: '#FFFF33' },
  { id: '35', code: 'neon-red', name: 'Neon Red', hex: '#FF4500' },
  { id: '36', code: 'neon-blue', name: 'Neon Blue', hex: '#00BFFF' },
  { id: '37', code: 'neon-green', name: 'Neon Green', hex: '#39FF14' },
  { id: '38', code: 'neon-orange', name: 'Neon Orange', hex: '#FF8C00' },
  { id: '43', code: 'pastel-yellow', name: 'Pastel Yellow', hex: '#FFFACD' },
  { id: '44', code: 'pastel-red', name: 'Pastel Red', hex: '#FFA07A' },
  { id: '45', code: 'pastel-purple', name: 'Pastel Purple', hex: '#DDA0DD' },
  { id: '46', code: 'pastel-blue', name: 'Pastel Blue', hex: '#ADD8E6' },
  { id: '47', code: 'pastel-green', name: 'Pastel Green', hex: '#98FB98' },
  { id: '48', code: 'pastel-pink', name: 'Pastel Pink', hex: '#FFC0CB' },
  { id: '70', code: 'light-grey', name: 'Light Grey', hex: '#D3D3D3' },
  { id: '79', code: 'apricot', name: 'Apricot', hex: '#FFB347' }
];

export const MINI_BEAD_COLORS = [
  { id: '01', code: 'white', name: 'White', hex: '#FFFFFF' },
  { id: '02', code: 'yellow', name: 'Yellow', hex: '#FFD700' },
  { id: '03', code: 'orange', name: 'Orange', hex: '#FFA500' },
  { id: '04', code: 'bright-red', name: 'Bright Red', hex: '#FF0000' },
  { id: '05', code: 'red', name: 'Red', hex: '#DC143C' },
  { id: '06', code: 'pink', name: 'Pink', hex: '#FFB6C1' },
  { id: '07', code: 'dark-blue', name: 'Dark Blue', hex: '#00008B' },
  { id: '08', code: 'bright-blue', name: 'Bright Blue', hex: '#1E90FF' },
  { id: '09', code: 'blue', name: 'Blue', hex: '#0000FF' },
  { id: '10', code: 'green', name: 'Green', hex: '#008000' },
  { id: '11', code: 'dark-green', name: 'Dark Green', hex: '#006400' },
  { id: '12', code: 'brown', name: 'Brown', hex: '#8B4513' },
  { id: '13', code: 'dark-red', name: 'Dark Red', hex: '#8B0000' },
  { id: '14', code: 'mustard-yellow', name: 'Mustard Yellow', hex: '#FFD12D' },
  { id: '15', code: 'turquoise', name: 'Turquoise', hex: '#40E0D0' },
  { id: '16', code: 'bright-green', name: 'Bright Green', hex: '#00FF00' },
  { id: '17', code: 'grey', name: 'Grey', hex: '#808080' },
  { id: '18', code: 'black', name: 'Black', hex: '#000000' },
  { id: '19', code: 'light-grey', name: 'Light Grey', hex: '#D3D3D3' },
  { id: '20', code: 'caramel', name: 'Caramel', hex: '#C19A6B' }
];

export function getBeadColors(type: 'MINI' | 'MAXI') {
  return type === 'MINI' ? MINI_BEAD_COLORS : MAXI_BEAD_COLORS;
}

export function findClosestColor(r: number, g: number, b: number, beadType: 'MINI' | 'MAXI') {
  const colors = getBeadColors(beadType);
  return colors.reduce((closest, current) => {
    const [cr, cg, cb] = hexToRgb(current.hex);
    const currentDistance = colorDistance(r, g, b, cr, cg, cb);
    const [prevR, prevG, prevB] = hexToRgb(closest.hex);
    const closestDistance = colorDistance(r, g, b, prevR, prevG, prevB);
    
    return currentDistance < closestDistance ? current : closest;
  }, colors[0]);
}

function hexToRgb(hex: string): [number, number, number] {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) {
    return [0, 0, 0];
  }
  return [
    parseInt(result[1], 16),
    parseInt(result[2], 16),
    parseInt(result[3], 16)
  ];
}

function colorDistance(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number): number {
  return Math.sqrt(
    Math.pow(r2 - r1, 2) +
    Math.pow(g2 - g1, 2) +
    Math.pow(b2 - b1, 2)
  );
}