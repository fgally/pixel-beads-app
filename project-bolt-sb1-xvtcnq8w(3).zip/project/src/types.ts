export interface BeadColor {
  code: string;
  name: string;
  hex: string;
  id: string;
}

export interface PixelData {
  x: number;
  y: number;
  color: BeadColor;
}

export type BeadType = 'MINI' | 'MAXI';

export interface PatternOptions {
  width: number;
  showGrid: boolean;
  patternStyle: 'symbols' | 'colors';
  beadType: BeadType;
}

export type ColorDistance = 'euclidean' | 'weighted-euclidean' | 'cie94' | 'ciede2000';